print("Enter digits. '.' - is end")
a = '.'
odd = 0
even = 0
first = True
a = raw_input('->')
while first or a != '.':
    correct = len(a) != 0
    if correct:
        correct = (a[0] >= '0' and a[0] <= '9') or (a[0] == '-' and len(a)>1)
    for x in range(1,len(a)):
        if a[x] < '0' or a[x] > '9':
            correct = False
    if correct == False:
        print ('not is integer')
    else:
        first = False
        a = int(a)
        if a % 2 == 0:
            even = even + 1
        else:
            odd = odd + 1
    a = raw_input('->')
print('odd count = ' + str(odd))
print('even count = ' + str(even))
